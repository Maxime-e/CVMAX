<a href="http://memo-web.fr" title="Ouverture d'une nouvelle fenêtre popup" 
     onclick="javascript:window.open(this.href,'nom_Popup',
                           'height=800 , width=600 , 
                            location=no , 
                            resizable=yes ,
                            scrollbars=yes');return false;"> Exemple d'ouverture d'une fenêtre en popup
</a>