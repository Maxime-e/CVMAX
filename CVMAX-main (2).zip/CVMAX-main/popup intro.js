<a href="https://github.com/Maxime-e/CVMAX/blob/main/index.html" title="intro" 
     onclick="javascript:window.open(this.href,'nom_Popup',
                           'height=400 , width=400 , 
                            location=no , 
                            resizable=yes ,
                            scrollbars=yes');return false;"> Exemple d'ouverture d'une fenêtre en popup
</a>    